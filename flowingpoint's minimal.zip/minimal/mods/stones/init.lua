stones = {}
default = {}

minetest.register_alias("stones:stone", "default:stone", "stones:rock")
minetest.register_alias("stones:dirt_with_grass", "default:dirt_with_grass", "stones:brush")
minetest.register_alias("stones:scree", "default:scree", "stones:rubble")

function default.node_sound_stone_defaults(table)
	table = table or {}
	table.footstep = table.footstep or
			{name="footstep", gain=0.2}
	default.node_sound_defaults(table)
	return table
end

minetest.register_node("stones:rock", {
	description = "Rock",
	paramtype = "light",
	tiles ={"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:rock',
	light_source = 0.005,
	legacy_mineral = false
})

minetest.register_node("stones:rubble", {
	description = "Rubble",
	tiles ={"rubble.png"},
	groups = {oddly_breakable_by_hand=1}
})

minetest.register_node("stones:brush", {
	description = "Brush",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles ={"grass.png", "dirt.png",
		{name = "dirt.png^grass_side.png",
		tileable_vertical = true}},
	groups = {crumbly=3, soil=1},
	drop = 'stones:brush',
	light_source = 0,
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_0", {
	description = "Brush | Rock",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_0.png", "rushrock_0.png^[transformFY", "brushrock_s.png^[transformFX", "brushrock_s.png", "rock.png", "dirt.png^grass_side.png"},
	groups = {cracky=3, soil=0},
	drop = "stones:brushrock_0",
	light_source = 0,
	node_box = {type= "fixed", fixed= 
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_1", {
	description = "Brush / Rock",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_1.png", "rushrock_1.png^[transformR90", {name = "dirt.png^grass_side.png", tileable_vertical = true}, "rock.png", "rock.png", {name = "dirt.png^grass_side.png", tileable_vertical = true}},
	groups = {cracky=3, soil=1},
	light_source = 0,
	drop = "stones:brushrock_1",
	node_box = {type= "fixed", fixed= 
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_2", {
	description = "Brush+Rock 3/1",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_2.png", "rushrock_2.png^[transformFY", "dirt.png^grass_side.png", "rock.png", "brushrock_s.png^[transformFX", "dirt.png^grass_side.png"},
	groups = {cracky=3, soil=1},
	light_source = 0,
	drop = "stones:brushrock_3",
	node_box = {type= "fixed", fixed= 
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_3", {
	description = "Brush+Rock 1/3",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_3.png", "rushrock_3.png^[transformFY", "dirt.png^grass_side.png", "rock.png",   "rock.png", "brushrock_s.png"},
	groups = {cracky=3, soil=0},
	light_source = 0,
	drop = "stones:brushrock_3",
	node_box = {type= "fixed", fixed= 
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_4", {
	description = "Brush+Rock 3/1",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_3.png^[transformFX^[transformR270", "rushrock_3.png^[transformR270", "rock.png", "brushrock_s.png^[transformFX", "dirt.png^grass_side.png", "rock.png",},
	groups = {cracky=3, soil=0},
	light_source = 0,
	drop = "stones:brushrock_4",
	node_box = {type= "fixed", fixed=
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_5", {
	description = "Brush+Rock 1/3",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"brushrock_2.png^[transformFX^[transformR270", "rushrock_2.png^[transformR270", "brushrock_s.png", "dirt.png^grass_side.png", "dirt.png^grass_side.png", "rock.png"},
	groups = {cracky=3, soil=1},
	light_source = 0,
	drop = "stones:brushrock_5",
	node_box = {type= "fixed", fixed=
{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("stones:brushrock_52ul", {
	description = "R5/2 Brush+Rock Left HighHalf ",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png","dirt.png^grass_side.png^[transformR270","brushrock_3.png^[transformFY^[transformR270","rushrock_3.png^[transformR270","brushrock_s.png^[transformFX^[transformR90","rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:brushrock_52ul",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52u.obj"
})

minetest.register_node("stones:brushrock_52ur", {
	description = "R5/2 Brush+Rock Right HighHalf ",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png","dirt.png^grass_side.png^[transformR90","rushrock_3.png^[transformFY^[transformR270","brushrock_3.png^[transformR270","brushrock_s.png^[transformR270","rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:brushrock_52ur",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52u.obj"
})

minetest.register_node("stones:brushrock_22", {
	description = "Root 2 Brushrock",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png","brushrock_s.png^[transformR270","brushrock_6.png","rushrock_6.png^[transformR270","brushrock_s.png^[transformFY^[transformR270"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:brushrock_22",
	collision_box = {type="fixed",fixed={
{-0.5,  -0.5,  -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.5, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.125, 0.5},
{-0.5, 0.125, 0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0.25, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,  -0.5,  -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.5, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.125, 0.5},
{-0.5, 0.125, 0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0.25, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_2.obj"
})

minetest.register_node("stones:sku", {
	description = "Diagonal SkewSlab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:sku',
	collision_box= { type= "fixed", fixed= {
{-0.5, -0.5, -0.5, 0.5, -0.4375, -0.375},
{-0.5, -0.4375, -0.5, 0.5, -0.375, -0.25},
{-0.5, -0.375, -0.5, 0.5, -0.3125, -0.125},
{-0.5, -0.3125, -0.5, 0.5, -0.25, 0},
{-0.5, -0.25, -0.5, 0.5, -0.1875, 0.125},
{-0.5, -0.1875, -0.5, 0.5, -0.125, 0.25},
{-0.5, -0.125, -0.5, 0.5, -0.0625, 0.375},
{-0.5, -0.0625, -0.5, 0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box= { type = "fixed", fixed = {
{-0.5, -0.5, -0.5, 0.5, -0.4375, -0.375},
{-0.5, -0.4375, -0.5, 0.5, -0.375, -0.25},
{-0.5, -0.375, -0.5, 0.5, -0.3125, -0.125},
{-0.5, -0.3125, -0.5, 0.5, -0.25, 0},
{-0.5, -0.25, -0.5, 0.5, -0.1875, 0.125},
{-0.5, -0.1875, -0.5, 0.5, -0.125, 0.25},
{-0.5, -0.125, -0.5, 0.5, -0.0625, 0.375},
{-0.5, -0.0625, -0.5, 0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "sku.obj",
	light_source = 0.005,
	is_ground_content = true,
})

minetest.register_node("stones:sku2_r", {
	description = "RightHalf SkewSlab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:sku2_r',
	collision_box= { type= "fixed", fixed= {
{0, -0.5, -0.5, 0.5, -0.4375, -0.375},
{0, -0.4375, -0.5, 0.5, -0.375, -0.25},
{0, -0.375, -0.5, 0.5, -0.3125, -0.125},
{0, -0.3125, -0.5, 0.5, -0.25, 0},
{0, -0.25, -0.5, 0.5, -0.1875, 0.125},
{0, -0.1875, -0.5, 0.5, -0.125, 0.25},
{0, -0.125, -0.5, 0.5, -0.0625, 0.375},
{0, -0.0625, -0.5, 0.5, 0.0625, 0.5},
{0, 0.0625, -0.375, 0.5, 0.125, 0.5},
{0, 0.125, -0.25, 0.5, 0.1875, 0.5},
{0, 0.1875, -0.125, 0.5, 0.25, 0.5},
{0, 0.25, 0, 0.5, 0.3125, 0.5},
{0, 0.3125, 0.125, 0.5, 0.375, 0.5},
{0, 0.375, 0.25, 0.5, 0.4375, 0.5},
{0, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box= { type = "fixed", fixed = {
{0, -0.5, -0.5, 0.5, -0.4375, -0.375},
{0, -0.4375, -0.5, 0.5, -0.375, -0.25},
{0, -0.375, -0.5, 0.5, -0.3125, -0.125},
{0, -0.3125, -0.5, 0.5, -0.25, 0},
{0, -0.25, -0.5, 0.5, -0.1875, 0.125},
{0, -0.1875, -0.5, 0.5, -0.125, 0.25},
{0, -0.125, -0.5, 0.5, -0.0625, 0.375},
{0, -0.0625, -0.5, 0.5, 0.0625, 0.5},
{0, 0.0625, -0.375, 0.5, 0.125, 0.5},
{0, 0.125, -0.25, 0.5, 0.1875, 0.5},
{0, 0.1875, -0.125, 0.5, 0.25, 0.5},
{0, 0.25, 0, 0.5, 0.3125, 0.5},
{0, 0.3125, 0.125, 0.5, 0.375, 0.5},
{0, 0.375, 0.25, 0.5, 0.4375, 0.5},
{0, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "sku2_r.obj",
	light_source = 0.005,
	is_ground_content = true,
})

minetest.register_node("stones:sku2_l", {
	description = "LeftHalf SkewSlab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:sku2_l',
	collision_box= { type= "fixed", fixed= {
{-0.5, -0.5, -0.5, 0, -0.4375, -0.375},
{-0.5, -0.4375, -0.5, 0, -0.375, -0.25},
{-0.5, -0.375, -0.5, 0, -0.3125, -0.125},
{-0.5, -0.3125, -0.5, 0, -0.25, 0},
{-0.5, -0.25, -0.5, 0, -0.1875, 0.125},
{-0.5, -0.1875, -0.5, 0, -0.125, 0.25},
{-0.5, -0.125, -0.5, 0, -0.0625, 0.375},
{-0.5, -0.0625, -0.5, 0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	selection_box= { type = "fixed", fixed = {
{-0.5, -0.5, -0.5, 0, -0.4375, -0.375},
{-0.5, -0.4375, -0.5, 0, -0.375, -0.25},
{-0.5, -0.375, -0.5, 0, -0.3125, -0.125},
{-0.5, -0.3125, -0.5, 0, -0.25, 0},
{-0.5, -0.25, -0.5, 0, -0.1875, 0.125},
{-0.5, -0.1875, -0.5, 0, -0.125, 0.25},
{-0.5, -0.125, -0.5, 0, -0.0625, 0.375},
{-0.5, -0.0625, -0.5, 0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "sku2_l.obj",
	light_source = 0.005,
	is_ground_content = true,
})

minetest.register_node("stones:sku3_l", {
	description = "R3 SkewSlab",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:sku3_l',
	collision_box= { type= "fixed", fixed= {
	{-0.0625,-0.5,-0.5, 0.5,0.0625,-0.375},
	{-0.125,-0.4375,-0.375, 0.4375,0.125,-0.25},
	{-0.1875,-0.375,-0.25, 0.375,0.1875,-0.125},
	{-0.25,-0.3125,-0.125, 0.3125,0.25,0},
	{-0.3125,-0.25,0, 0.25,0.3125,0.125},
	{-0.375,-0.1875,0.125, 0.1875,0.375,0.25},
	{-0.4375,-0.125,0.25, 0.125,0.4375,0.375},
	{-0.5,-0.0625,0.375, 0.0625,0.5,0.5}}},
selection_box= { type = "fixed", fixed = {
	{-0.0625,-0.5,-0.5, 0.5,0.0625,-0.375},
	{-0.125,-0.4375,-0.375, 0.4375,0.125,-0.25},
	{-0.1875,-0.375,-0.25, 0.375,0.1875,-0.125},
	{-0.25,-0.3125,-0.125, 0.3125,0.25,0},
	{-0.3125,-0.25,0, 0.25,0.3125,0.125},
	{-0.375,-0.1875,0.125, 0.1875,0.375,0.25},
	{-0.4375,-0.125,0.25, 0.125,0.4375,0.375},
	{-0.5,-0.0625,0.375, 0.0625,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "sku3_l.obj",
	light_source = 0.005,
	is_ground_content = true,
})

minetest.register_node("stones:sku3_r", {
	description = "R3 SkewSlab Alt",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = 'stones:sku3_r',
	collision_box= { type= "fixed", fixed= {
{-0.5,-0.5,-0.5, 0.0625,0.0625,-0.375},
{-0.4375,-0.4375,-0.375, 0.125,0.125,-0.25},
{-0.375,-0.375,-0.25, 0.1875,0.1875,-0.125},
{-0.3125,-0.3125,-0.125, 0.25,0.25,0},
{-0.25,-0.25,0, 0.3125,0.3125,0.125},
{-0.1875,-0.1875,0.125, 0.375,0.375,0.25},
{-0.125,-0.125,0.25, 0.4375,0.4375,0.375},
{-0.0625,-0.0625,0.375, 0.5,0.5,0.5}}},
selection_box= { type = "fixed", fixed = {
{-0.5,-0.5,-0.5, 0.0625,0.0625,-0.375},
{-0.4375,-0.4375,-0.375, 0.125,0.125,-0.25},
{-0.375,-0.375,-0.25, 0.1875,0.1875,-0.125},
{-0.3125,-0.3125,-0.125, 0.25,0.25,0},
{-0.25,-0.25,0, 0.3125,0.3125,0.125},
{-0.1875,-0.1875,0.125, 0.375,0.375,0.25},
{-0.125,-0.125,0.25, 0.4375,0.4375,0.375},
{-0.0625,-0.0625,0.375, 0.5,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "sku3_r.obj",
	light_source = 0.005,
	is_ground_content = true,
})

minetest.register_node("stones:diagsteps", {
	description = "Diagonal Steps",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:diagsteps",
	collision_box={type="fixed",fixed={
{-0.5, -0.5, 0, 0.0625, 0.5, 0.5},
{0.0625, -0.5, 0.0625, 0.125, 0.5, 0.5},
{0.125, -0.5, 0.125, 0.1875, 0.5, 0.5},
{0.1875, -0.5, 0.1875, 0.25, 0.5, 0.5},
{0.25, -0.5, 0.25, 0.3125, 0.5, 0.5},
{0.3125, -0.5, 0.3125, 0.375, 0.5, 0.5},
{0.375, -0.5, 0.375, 0.4375, 0.5, 0.5},
{0.4375, -0.5, 0.4375, 0.5, 0.5, 0.5},
{-0.5, -0.5, -0.5, -0.4375, 0.5, -0.4375},
{-0.5, -0.5, -0.4375, -0.375, 0.5, -0.375},
{-0.5, -0.5, -0.375, -0.3125, 0.5, -0.3125},
{-0.5, -0.5, -0.3125, -0.25, 0.5, -0.25},
{-0.5, -0.5, -0.25, -0.1875, 0.5, -0.1875},
{-0.5, -0.5, -0.1875, -0.125, 0.5, -0.125},
{-0.5, -0.5, -0.125, -0.0625, 0.5, -0.0625},
{-0.5, -0.5, -0.0625, 0, 0.5, 0},
{-0.5, -0.5, -0.5, 0.5, 0, 0.5}}},
	selection_box={type="fixed",fixed={
{-0.5, -0.5, 0, 0.0625, 0.5, 0.5},
{0.0625, -0.5, 0.0625, 0.125, 0.5, 0.5},
{0.125, -0.5, 0.125, 0.1875, 0.5, 0.5},
{0.1875, -0.5, 0.1875, 0.25, 0.5, 0.5},
{0.25, -0.5, 0.25, 0.3125, 0.5, 0.5},
{0.3125, -0.5, 0.3125, 0.375, 0.5, 0.5},
{0.375, -0.5, 0.375, 0.4375, 0.5, 0.5},
{0.4375, -0.5, 0.4375, 0.5, 0.5, 0.5},
{-0.5, -0.5, -0.5, -0.4375, 0.5, -0.4375},
{-0.5, -0.5, -0.4375, -0.375, 0.5, -0.375},
{-0.5, -0.5, -0.375, -0.3125, 0.5, -0.3125},
{-0.5, -0.5, -0.3125, -0.25, 0.5, -0.25},
{-0.5, -0.5, -0.25, -0.1875, 0.5, -0.1875},
{-0.5, -0.5, -0.1875, -0.125, 0.5, -0.125},
{-0.5, -0.5, -0.125, -0.0625, 0.5, -0.0625},
{-0.5, -0.5, -0.0625, 0, 0.5, 0},
{-0.5, -0.5, -0.5, 0.5, 0, 0.5}}},
	drawtype="mesh",
	mesh = "diagsteps.obj"
})

minetest.register_node("stones:diagstep", {
	description = "Diagonal Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:diagstep",
	collision_box={type="fixed",fixed={
{-0.5, -0.5, 0, 0.0625, 0, 0.5},
{0.0625, -0.5, 0.0625, 0.125, 0, 0.5},
{0.125, -0.5, 0.125, 0.1875, 0, 0.5},
{0.1875, -0.5, 0.1875, 0.25, 0, 0.5},
{0.25, -0.5, 0.25, 0.3125, 0, 0.5},
{0.3125, -0.5, 0.3125, 0.375, 0, 0.5},
{0.375, -0.5, 0.375, 0.4375, 0, 0.5},
{0.4375, -0.5, 0.4375, 0.5, 0, 0.5},
{-0.5, -0.5, -0.5, -0.4375, 0, -0.4375},
{-0.5, -0.5, -0.4375, -0.375, 0, -0.375},
{-0.5, -0.5, -0.375, -0.3125, 0, -0.3125},
{-0.5, -0.5, -0.3125, -0.25, 0, -0.25},
{-0.5, -0.5, -0.25, -0.1875, 0, -0.1875},
{-0.5, -0.5, -0.1875, -0.125, 0, -0.125},
{-0.5, -0.5, -0.125, -0.0625, 0, -0.0625},
{-0.5, -0.5, -0.0625, 0, 0, 0}}},
	selection_box={type="fixed",fixed={
{-0.5, -0.5, 0, 0.0625, 0, 0.5},
{0.0625, -0.5, 0.0625, 0.125, 0, 0.5},
{0.125, -0.5, 0.125, 0.1875, 0, 0.5},
{0.1875, -0.5, 0.1875, 0.25, 0, 0.5},
{0.25, -0.5, 0.25, 0.3125, 0, 0.5},
{0.3125, -0.5, 0.3125, 0.375, 0, 0.5},
{0.375, -0.5, 0.375, 0.4375, 0, 0.5},
{0.4375, -0.5, 0.4375, 0.5, 0, 0.5},
{-0.5, -0.5, -0.5, -0.4375, 0, -0.4375},
{-0.5, -0.5, -0.4375, -0.375, 0, -0.375},
{-0.5, -0.5, -0.375, -0.3125, 0, -0.3125},
{-0.5, -0.5, -0.3125, -0.25, 0, -0.25},
{-0.5, -0.5, -0.25, -0.1875, 0, -0.1875},
{-0.5, -0.5, -0.1875, -0.125, 0, -0.125},
{-0.5, -0.5, -0.125, -0.0625, 0, -0.0625},
{-0.5, -0.5, -0.0625, 0, 0, 0}}},
	drawtype="mesh",
	mesh = "diagstep.obj"
})

function nb(n)
	return n/16-1/2
end
	
minetest.register_node("stones:arch", {
	description = "Arch",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "nodebox",
	node_box = {type = "fixed", fixed = {
{nb(0), nb(0), nb(0), nb(1), nb(16), nb(16)},
{nb(1), nb(4), nb(0), nb(2), nb(16), nb(16)},
{nb(2), nb(7), nb(0), nb(3), nb(16), nb(16)},
{nb(3), nb(8), nb(0), nb(4), nb(16), nb(16)},
{nb(4), nb(10), nb(0), nb(5), nb(16), nb(16)},
{nb(5), nb(11), nb(0), nb(6), nb(16), nb(16)},
{nb(6), nb(12), nb(0), nb(8), nb(16), nb(16)},
{nb(8), nb(13), nb(0), nb(9), nb(16), nb(16)},
{nb(9), nb(14), nb(0), nb(12), nb(16), nb(16)},
{nb(12), nb(15), nb(0), nb(16), nb(16), nb(16)}}},
	groups = {cracky=3,oddly_breakable_by_hand=0},
	drop = "stones:arch"
})
	
minetest.register_node("stones:arco", {
	description = "Outer Arc",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "nodebox",
	node_box = {type = "fixed", fixed = {
{nb(0), nb(0), nb(16), nb(1), nb(16), nb(16-1)},
{nb(0), nb(4), nb(16), nb(2), nb(16), nb(16-2)},
{nb(0), nb(7), nb(16), nb(3), nb(16), nb(16-3)},
{nb(0), nb(8), nb(16), nb(4), nb(16), nb(16-4)},
{nb(0), nb(10), nb(16), nb(5), nb(16), nb(16-5)},
{nb(0), nb(11), nb(16), nb(6), nb(16), nb(16-6)},
{nb(0), nb(12), nb(16), nb(8), nb(16), nb(16-8)},
{nb(0), nb(13), nb(16), nb(9), nb(16), nb(16-9)},
{nb(0), nb(14), nb(16), nb(12), nb(16), nb(16-12)},
{nb(0), nb(15), nb(16), nb(16), nb(16), nb(16-16)}}},
	groups = {cracky=3,oddly_breakable_by_hand=0},
	drop = "stones:arco"
})

minetest.register_node("stones:arci", {
	description = "Inner Arc",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	drawtype = "nodebox",
	node_box = {type = "fixed", fixed = {
{nb(0), nb(0), nb(16), nb(1), nb(16), nb(0)},
{nb(0), nb(0), nb(16), nb(16), nb(16), nb(16-1)},
{nb(0), nb(4), nb(16), nb(2), nb(16), nb(0)},
{nb(0), nb(4), nb(16), nb(16), nb(16), nb(16-2)},
{nb(0), nb(7), nb(16), nb(3), nb(16), nb(0)},
{nb(0), nb(7), nb(16), nb(16), nb(16), nb(16-3)},
{nb(0), nb(8), nb(16), nb(4), nb(16), nb(0)},
{nb(0), nb(8), nb(16), nb(16), nb(16), nb(16-4)},
{nb(0), nb(10), nb(16), nb(5), nb(16), nb(0)},
{nb(0), nb(10), nb(16), nb(16), nb(16), nb(16-5)},
{nb(0), nb(11), nb(16), nb(6), nb(16), nb(0)},
{nb(0), nb(11), nb(16), nb(16), nb(16), nb(16-6)},
{nb(0), nb(12), nb(16), nb(8), nb(16), nb(0)},
{nb(0), nb(12), nb(16), nb(16), nb(16), nb(16-8)},
{nb(0), nb(13), nb(16), nb(9), nb(16), nb(0)},
{nb(0), nb(13), nb(16), nb(16), nb(16), nb(16-9)},
{nb(0), nb(14), nb(16), nb(12), nb(16), nb(0)},
{nb(0), nb(14), nb(16), nb(16), nb(16), nb(16-12)},
{nb(0), nb(15), nb(16), nb(16), nb(16), nb(16-16)}}},
	groups = {cracky=1,oddly_breakable_by_hand=0},
	drop = "stones:arci"
})

minetest.register_node("stones:s_2", {
	description = "Root 2 Slope",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_2",
	collision_box = {type="fixed",fixed={
{-0.5,  -0.5,  -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.5, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.125, 0.5},
{-0.5, 0.125, 0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0.25, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,  -0.5,  -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.5, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.125, 0.5},
{-0.5, 0.125, 0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0.25, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_2.obj"
})
	
minetest.register_node("stones:s_52", {
	description = "R5/2 Slope LowHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.375, 0.5, -0.375,  0.5},
{-0.5, -0.375, -0.25, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0.5, -0.25, 0.5},
{-0.5, -0.25, 0, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0.5, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, 0.5, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.375, 0.5, -0.375,  0.5},
{-0.5, -0.375, -0.25, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0.5, -0.25, 0.5},
{-0.5, -0.25, 0, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0.5, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, 0.5, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52.obj"
})

minetest.register_node("stones:s_52l", {
	description = "R5/2 Slope LowHalf Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52l",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0, -0.4375, 0.5},
{-0.5, -0.4375, -0.375, 0, -0.375,  0.5},
{-0.5, -0.375, -0.25, 0, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0, -0.25, 0.5},
{-0.5, -0.25, 0, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, 0, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, 0, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0, -0.4375, 0.5},
{-0.5, -0.4375, -0.375, 0, -0.375,  0.5},
{-0.5, -0.375, -0.25, 0, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0, -0.25, 0.5},
{-0.5, -0.25, 0, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, 0, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, 0, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52l.obj"
})

minetest.register_node("stones:s_52r", {
	description = "R5/2 Slope LowHalf Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52r",
	collision_box = {type="fixed",fixed={
{0, -0.5,   -0.5,  0.5, -0.4375, 0.5},
{0, -0.4375, -0.375, 0.5, -0.375,  0.5},
{0, -0.375, -0.25, 0.5, -0.3125, 0.5},
{0, -0.3125, -0.125, 0.5, -0.25, 0.5},
{0, -0.25, 0, 0.5, -0.1875, 0.5},
{0, -0.1875, 0.125, 0.5, -0.125, 0.5},
{0, -0.125, 0.25, 0.5, -0.0625, 0.5},
{0, -0.0625, 0.375, 0.5, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{0, -0.5,   -0.5,  0.5, -0.4375, 0.5},
{0, -0.4375, -0.375, 0.5, -0.375,  0.5},
{0, -0.375, -0.25, 0.5, -0.3125, 0.5},
{0, -0.3125, -0.125, 0.5, -0.25, 0.5},
{0, -0.25, 0, 0.5, -0.1875, 0.5},
{0, -0.1875, 0.125, 0.5, -0.125, 0.5},
{0, -0.125, 0.25, 0.5, -0.0625, 0.5},
{0, -0.0625, 0.375, 0.5, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52r.obj"
})

minetest.register_node("stones:s_22", {
	description = "R2/2 Slope Edgefill",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_22",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   0,  0.5, -0.4375, 0.5},
{-0.5, -0.4375, 0.0625, 0.5, -0.375,  0.5},
{-0.5, -0.375, 0.125, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, 0.1875, 0.5, -0.25, 0.5},
{-0.5, -0.25, 0.25, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, 0.3125, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.375, 0.5, -0.0625, 0.5},
{-0.5, -0.0625, 0.4375, 0.5, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   0,  0.5, -0.4375, 0.5},
{-0.5, -0.4375, 0.0625, 0.5, -0.375,  0.5},
{-0.5, -0.375, 0.125, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, 0.1875, 0.5, -0.25, 0.5},
{-0.5, -0.25, 0.25, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, 0.3125, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.375, 0.5, -0.0625, 0.5},
{-0.5, -0.0625, 0.4375, 0.5, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_22.obj"
})

minetest.register_node("stones:s_22l", {
	description = "R2/2 Slope Cornerfill Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_22l",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   0,  0, -0.4375, 0.5},
{-0.5, -0.4375, 0.0625, 0, -0.375,  0.5},
{-0.5, -0.375, 0.125, 0, -0.3125, 0.5},
{-0.5, -0.3125, 0.1875, 0, -0.25, 0.5},
{-0.5, -0.25, 0.25, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.3125, 0, -0.125, 0.5},
{-0.5, -0.125, 0.375, 0, -0.0625, 0.5},
{-0.5, -0.0625, 0.4375, 0, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   0,  0, -0.4375, 0.5},
{-0.5, -0.4375, 0.0625, 0, -0.375,  0.5},
{-0.5, -0.375, 0.125, 0, -0.3125, 0.5},
{-0.5, -0.3125, 0.1875, 0, -0.25, 0.5},
{-0.5, -0.25, 0.25, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.3125, 0, -0.125, 0.5},
{-0.5, -0.125, 0.375, 0, -0.0625, 0.5},
{-0.5, -0.0625, 0.4375, 0, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_22l.obj"
})

minetest.register_node("stones:s_22r", {
	description = "R2/2 Slope Cornerfill Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_22r",
	collision_box = {type="fixed",fixed={
{0, -0.5,   0,  0.5, -0.4375, 0.5},
{0, -0.4375, 0.0625, 0.5, -0.375,  0.5},
{0, -0.375, 0.125, 0.5, -0.3125, 0.5},
{0, -0.3125, 0.1875, 0.5, -0.25, 0.5},
{0, -0.25, 0.25, 0.5, -0.1875, 0.5},
{0, -0.1875, 0.3125, 0.5, -0.125, 0.5},
{0, -0.125, 0.375, 0.5, -0.0625, 0.5},
{0, -0.0625, 0.4375, 0.5, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{0, -0.5,   0,  0.5, -0.4375, 0.5},
{0, -0.4375, 0.0625, 0.5, -0.375,  0.5},
{0, -0.375, 0.125, 0.5, -0.3125, 0.5},
{0, -0.3125, 0.1875, 0.5, -0.25, 0.5},
{0, -0.25, 0.25, 0.5, -0.1875, 0.5},
{0, -0.1875, 0.3125, 0.5, -0.125, 0.5},
{0, -0.125, 0.375, 0.5, -0.0625, 0.5},
{0, -0.0625, 0.4375, 0.5, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "s_22r.obj"
})

minetest.register_node("stones:spike", {
	description = "Spike",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:spike",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, 0.375, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, 0.25, 0.5, -0.375, 0.5},
{-0.5, -0.375, 0.125, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, 0, 0.5, -0.25, 0.5},	
{-0.5, -0.25, -0.125, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.375, 0.5, -0.0625, 0.5},
{-0.5, -0.0625,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125,  0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, 0.375, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, 0.25, 0.5, -0.375, 0.5},
{-0.5, -0.375, 0.125, 0.5, -0.3125, 0.5},
{-0.5, -0.3125, 0, 0.5, -0.25, 0.5},	
{-0.5, -0.25, -0.125, 0.5, -0.1875, 0.5},
{-0.5, -0.1875, -0.25, 0.5, -0.125, 0.5},
{-0.5, -0.125, -0.375, 0.5, -0.0625, 0.5},
{-0.5, -0.0625,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125,  0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "spike.obj"
})

minetest.register_node("stones:spikle", {
	description = "Spikle",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:spikle",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, 0.375, 0, -0.4375, 0.5},
{-0.5, -0.4375, 0.25, 0, -0.375, 0.5},
{-0.5, -0.375, 0.125, 0, -0.3125, 0.5},
{-0.5, -0.3125, 0, 0, -0.25, 0.5},	
{-0.5, -0.25, -0.125, 0, -0.1875, 0.5},
{-0.5, -0.1875, -0.25, 0, -0.125, 0.5},
{-0.5, -0.125, -0.375, 0, -0.0625, 0.5},
{-0.5, -0.0625,   -0.5,  0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125,  0.5},
{-0.5, 0.125, -0.25, 0, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, 0.375, 0, -0.4375, 0.5},
{-0.5, -0.4375, 0.25, 0, -0.375, 0.5},
{-0.5, -0.375, 0.125, 0, -0.3125, 0.5},
{-0.5, -0.3125, 0, 0, -0.25, 0.5},	
{-0.5, -0.25, -0.125, 0, -0.1875, 0.5},
{-0.5, -0.1875, -0.25, 0, -0.125, 0.5},
{-0.5, -0.125, -0.375, 0, -0.0625, 0.5},
{-0.5, -0.0625,   -0.5,  0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125,  0.5},
{-0.5, 0.125, -0.25, 0, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "spikle.obj"
})


minetest.register_node("stones:s_52u", {
	description = "R5/2 Slope HighHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52u",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0.5, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.5, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0.5, 0.25, 0.5},
{-0.5, 0.25, 0, 0.5, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0.5, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0.5, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52u.obj"
})

minetest.register_node("stones:s_52ul", {
	description = "R5/2 Slope HighHalf Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52ul",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5,   -0.5,  0, 0.0625, 0.5},
{-0.5, 0.0625, -0.375, 0, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0, 0.1825, 0.5},
{-0.5, 0.1825, -0.125, 0, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, 0, 0.375, 0.5},
{-0.5, 0.375, 0.25, 0, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, 0, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52ul.obj"
})

minetest.register_node("stones:s_52ur", {
	description = "R5/2 Slope HighHalf Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_52ur",
	collision_box = {type="fixed",fixed={
{0, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{0, 0.0625, -0.375, 0.5, 0.125, 0.5},
{0, 0.125, -0.25, 0.5, 0.1825, 0.5},
{0, 0.1825, -0.125, 0.5, 0.25, 0.5},
{0, 0.25, 0, 0.5, 0.3125, 0.5},
{0, 0.3125, 0.125, 0.5, 0.375, 0.5},
{0, 0.375, 0.25, 0.5, 0.4375, 0.5},
{0, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{0, -0.5,   -0.5,  0.5, 0.0625, 0.5},
{0, 0.0625, -0.375, 0.5, 0.125, 0.5},
{0, 0.125, -0.25, 0.5, 0.1825, 0.5},
{0, 0.1825, -0.125, 0.5, 0.25, 0.5},
{0, 0.25, 0, 0.5, 0.3125, 0.5},
{0, 0.3125, 0.125, 0.5, 0.375, 0.5},
{0, 0.375, 0.25, 0.5, 0.4375, 0.5},
{0, 0.4375, 0.375, 0.5, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_52ur.obj"
})

minetest.register_node("stones:asect", {
	description = "Apex Inset Nsecting",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:asect",
	collision_box = {type="fixed",fixed={
		{-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
		{-0.5, -0.5, -0.25, 0.5, 0, 0.5},
		{-0.5, -0.5, -0.5, 0.25, 0, 0.5},
		{-0.5, 0, -0.5, 0, 0.25, 0.5},
		{-0.5, 0, 0, 0.5, 0.25, 0.5},
		{-0.5, 0.25, 0.25, 0.5, 0.5, 0.5},
		{-0.5, 0.25, -0.5, -0.25, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
		{-0.5, -0.5, -0.5, 0.5, -0.25, 0.5},
		{-0.5, -0.5, -0.25, 0.5, 0, 0.5},
		{-0.5, -0.5, -0.5, 0.25, 0, 0.5},
		{-0.5, 0, -0.5, 0, 0.25, 0.5},
		{-0.5, 0, 0, 0.5, 0.25, 0.5},
		{-0.5, 0.25, 0.25, 0.5, 0.5, 0.5},
		{-0.5, 0.25, -0.5, -0.25, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "asect.obj"
})

minetest.register_node("stones:asect_2", {
	description = "Apex Inset Nsecting LowHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:asect_2",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.25, 0.5, -0.25, 0.5},
{-0.5, -0.375, -0.5, 0.25, -0.25, 0.5},
{-0.5, -0.25, -0.5, 0, -0.125, 0.5},
{-0.5, -0.25, 0, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0.5, 0, 0.5},
{-0.5, -0.125, -0.5, -0.25, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.25, 0.5, -0.25, 0.5},
{-0.5, -0.375, -0.5, 0.25, -0.25, 0.5},
{-0.5, -0.25, -0.5, 0, -0.125, 0.5},
{-0.5, -0.25, 0, 0.5, -0.125, 0.5},
{-0.5, -0.125, 0.25, 0.5, 0, 0.5},
{-0.5, -0.125, -0.5, -0.25, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "asect_2.obj"
})


minetest.register_node("stones:asect_2u", {
	description = "Apex Inset Nsecting HighHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:asect_2u",
	collision_box = {type="fixed",fixed={
		{-0.5, -0.5, -0.5, 0.5, 0.125, 0.5},
		{-0.5, 0.125, -0.25, 0.5, 0.25, 0.5},
		{-0.5, 0.125, -0.5, 0.25, 0.25, 0.5},
		{-0.5, 0.25, -0.5, 0, 0.375, 0.5},
		{-0.5, 0.25, 0, 0.5, 0.375, 0.5},
		{-0.5, 0.375, 0.25, 0.5, 0.5, 0.5},
		{-0.5, 0.375, -0.5, -0.25, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
		{-0.5, -0.5, -0.5, 0.5, 0.125, 0.5},
		{-0.5, 0.125, -0.25, 0.5, 0.25, 0.5},
		{-0.5, 0.125, -0.5, 0.25, 0.25, 0.5},
		{-0.5, 0.25, -0.5, 0, 0.375, 0.5},
		{-0.5, 0.25, 0, 0.5, 0.375, 0.5},
		{-0.5, 0.375, 0.25, 0.5, 0.5, 0.5},
		{-0.5, 0.375, -0.5, -0.25, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "asect_2u.obj"
})

minetest.register_node("stones:vsect", {
	description = "Vertex Filled Nsecting",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vsect",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.4375,  0.4375, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.375, -0.3125, 0.5},
{-0.5, -0.3125, -0.3125, 0.3125, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.25, -0.1875, 0.5},
{-0.5, -0.1875, -0.1875, 0.1875, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.125, -0.0625, 0.5},
{-0.5, -0.0625, -0.0625, 0.0625 , 0, 0.5},
{-0.5, 0, 0, 0, 0.0625, 0.5},
{-0.5, 0.0625, 0.0625, -0.0625, 0.125, 0.5},
{-0.5, 0.125, 0.125, -0.125, 0.1875, 0.5},
{-0.5, 0.1875, 0.1875, -0.1875, 0.25, 0.5},
{-0.5, 0.25, 0.25, -0.25, 0.3125, 0.5},
{-0.5, 0.3125, 0.3125, -0.3125, 0.375, 0.5},
{-0.5, 0.375, 0.375, -0.375, 0.4375, 0.5},
{-0.5, 0.4375, 0.4375, -0.4375, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.4375,  0.4375, -0.375, 0.5},
{-0.5, -0.375, -0.375, 0.375, -0.3125, 0.5},
{-0.5, -0.3125, -0.3125, 0.3125, -0.25, 0.5},
{-0.5, -0.25, -0.25, 0.25, -0.1875, 0.5},
{-0.5, -0.1875, -0.1875, 0.1875, -0.125, 0.5},
{-0.5, -0.125, -0.125, 0.125, -0.0625, 0.5},
{-0.5, -0.0625, -0.0625, 0.0625 , 0, 0.5},
{-0.5, 0, 0, 0, 0.0625, 0.5},
{-0.5, 0.0625, 0.0625, -0.0625, 0.125, 0.5},
{-0.5, 0.125, 0.125, -0.125, 0.1875, 0.5},
{-0.5, 0.1875, 0.1875, -0.1875, 0.25, 0.5},
{-0.5, 0.25, 0.25, -0.25, 0.3125, 0.5},
{-0.5, 0.3125, 0.3125, -0.3125, 0.375, 0.5},
{-0.5, 0.375, 0.375, -0.375, 0.4375, 0.5},
{-0.5, 0.4375, 0.4375, -0.4375, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "vsect.obj"
})

minetest.register_node("stones:vsect_2", {
	description = "Vertex Filled Nsecting LowHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vsect_2",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.375,  0.375, -0.375, 0.5},
{-0.5, -0.375, -0.25, 0.25, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0.125, -0.25, 0.5},
{-0.5, -0.25, 0, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, -0.125, -0.125, 0.5},
{-0.5, -0.125, 0.25, -0.25, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, -0.375, 0, 0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5},
{-0.5, -0.4375, -0.375,  0.375, -0.375, 0.5},
{-0.5, -0.375, -0.25, 0.25, -0.3125, 0.5},
{-0.5, -0.3125, -0.125, 0.125, -0.25, 0.5},
{-0.5, -0.25, 0, 0, -0.1875, 0.5},
{-0.5, -0.1875, 0.125, -0.125, -0.125, 0.5},
{-0.5, -0.125, 0.25, -0.25, -0.0625, 0.5},
{-0.5, -0.0625, 0.375, -0.375, 0, 0.5}}},
	drawtype = "mesh",
	mesh = "vsect_2.obj"
})

minetest.register_node("stones:vsect_2u", {
	description = "Vertex Filled Nsecting HighHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vsect_2u",
	collision_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375,  0.375, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.25, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.125, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, -0.125, 0.375, 0.5},
{-0.5, 0.375, 0.25, -0.25, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, -0.375, 0.5, 0.5}}},	
	selection_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, 0.0625, 0.5},
{-0.5, 0.0625, -0.375,  0.375, 0.125, 0.5},
{-0.5, 0.125, -0.25, 0.25, 0.1875, 0.5},
{-0.5, 0.1875, -0.125, 0.125, 0.25, 0.5},
{-0.5, 0.25, 0, 0, 0.3125, 0.5},
{-0.5, 0.3125, 0.125, -0.125, 0.375, 0.5},
{-0.5, 0.375, 0.25, -0.25, 0.4375, 0.5},
{-0.5, 0.4375, 0.375, -0.375, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "vsect_2u.obj"
})

minetest.register_node("stones:aset", {
	description = "Apex Inset",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:aset",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,-0.3,0.5},
{-0.3,-0.5,-0.3, -0.1,-0.3,0.5},
{-0.1,-0.5,-0.1, 0.1,-0.3,0.5},
{0.1,-0.5,0.1, 0.3,-0.3,0.5},
{0.3,-0.5,0.3, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.3, -0.3,-0.1,0.5},
{-0.3,-0.3,-0.1, -0.1,-0.1,0.5},
{-0.1,-0.3,0.1, 0.1,-0.1,0.5},
{0.1,-0.3,0.3, 0.3,-0.1,0.5},
{-0.5,-0.1,-0.1, -0.3,0.1,0.5},
{-0.3,-0.1,0.1, -0.1,0.1,0.5},
{-0.1,-0.1,0.3, 0.1,0.1,0.5},
{-0.5,0.1,0.1, -0.3,0.3,0.5},
{-0.3,0.1,0.3, -0.1,0.3,0.5},
{-0.5,0.3,0.3, -0.3,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,-0.3,0.5},
{-0.3,-0.5,-0.3, -0.1,-0.3,0.5},
{-0.1,-0.5,-0.1, 0.1,-0.3,0.5},
{0.1,-0.5,0.1, 0.3,-0.3,0.5},
{0.3,-0.5,0.3, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.3, -0.3,-0.1,0.5},
{-0.3,-0.3,-0.1, -0.1,-0.1,0.5},
{-0.1,-0.3,0.1, 0.1,-0.1,0.5},
{0.1,-0.3,0.3, 0.3,-0.1,0.5},
{-0.5,-0.1,-0.1, -0.3,0.1,0.5},
{-0.3,-0.1,0.1, -0.1,0.1,0.5},
{-0.1,-0.1,0.3, 0.1,0.1,0.5},
{-0.5,0.1,0.1, -0.3,0.3,0.5},
{-0.3,0.1,0.3, -0.1,0.3,0.5},
{-0.5,0.3,0.3, -0.3,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "aset.obj"
})

minetest.register_node("stones:aset_2", {
	description = "Apex Inset LowHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:aset_2",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,-0.4,0.5},
{-0.3,-0.5,-0.3, -0.1,-0.4,0.5},
{-0.1,-0.5,-0.1, 0.1,-0.4,0.5},
{0.1,-0.5,0.1, 0.3,-0.4,0.5},
{0.3,-0.5,0.3, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.3, -0.3,-0.3,0.5},
{-0.3,-0.4,-0.1, -0.1,-0.3,0.5},
{-0.1,-0.4,0.1, 0.1,-0.3,0.5},
{0.1,-0.4,0.3, 0.3,-0.3,0.5},
{-0.5,-0.3,-0.1, -0.3,-0.2,0.5},
{-0.3,-0.3,0.1, -0.1,-0.2,0.5},
{-0.1,-0.3,0.3, 0.1,-0.2,0.5},
{-0.5,-0.2,0.1, -0.3,-0.1,0.5},
{-0.3,-0.2,0.3, -0.1,-0.1,0.5},
{-0.5,-0.1,0.3, -0.3,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,-0.4,0.5},
{-0.3,-0.5,-0.3, -0.1,-0.4,0.5},
{-0.1,-0.5,-0.1, 0.1,-0.4,0.5},
{0.1,-0.5,0.1, 0.3,-0.4,0.5},
{0.3,-0.5,0.3, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.3, -0.3,-0.3,0.5},
{-0.3,-0.4,-0.1, -0.1,-0.3,0.5},
{-0.1,-0.4,0.1, 0.1,-0.3,0.5},
{0.1,-0.4,0.3, 0.3,-0.3,0.5},
{-0.5,-0.3,-0.1, -0.3,-0.2,0.5},
{-0.3,-0.3,0.1, -0.1,-0.2,0.5},
{-0.1,-0.3,0.3, 0.1,-0.2,0.5},
{-0.5,-0.2,0.1, -0.3,-0.1,0.5},
{-0.3,-0.2,0.3, -0.1,-0.1,0.5},
{-0.5,-0.1,0.3, -0.3,0,0.5}}},
	drawtype = "mesh",
	mesh = "aset_2.obj"
})

minetest.register_node("stones:aset_2u", {
	description = "Apex Inset HighHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:aset_2u",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,0,0.5},
{-0.3,-0.5,-0.3, -0.1,0,0.5},
{-0.1,-0.5,-0.1, 0.1,0,0.5},
{0.1,-0.5,0.1, 0.3,0,0.5},
{0.3,-0.5,0.3, 0.5,0,0.5},
{-0.5,0.1,-0.3, -0.3,0.125,0.5},
{-0.3,0.1,-0.1, -0.1,0.125,0.5},
{-0.1,0.1,0.1, 0.1,0.125,0.5},
{0.1,0.1,0.3, 0.3,0.125,0.5},
{-0.5,0.2,-0.1, -0.3,0.25,0.5},
{-0.3,0.2,0.1, -0.1,0.25,0.5},
{-0.1,0.2,0.3, 0.1,0.25,0.5},
{-0.5,0.3,0.1, -0.3,0.375,0.5},
{-0.3,0.3,0.3, -0.1,0.375,0.5},
{-0.5,0.4,0.3, -0.3,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, -0.3,0,0.5},
{-0.3,-0.5,-0.3, -0.1,0,0.5},
{-0.1,-0.5,-0.1, 0.1,0,0.5},
{0.1,-0.5,0.1, 0.3,0,0.5},
{0.3,-0.5,0.3, 0.5,0,0.5},
{-0.5,0.1,-0.3, -0.3,0.125,0.5},
{-0.3,0.1,-0.1, -0.1,0.125,0.5},
{-0.1,0.1,0.1, 0.1,0.125,0.5},
{0.1,0.1,0.3, 0.3,0.125,0.5},
{-0.5,0.2,-0.1, -0.3,0.25,0.5},
{-0.3,0.2,0.1, -0.1,0.25,0.5},
{-0.1,0.2,0.3, 0.1,0.25,0.5},
{-0.5,0.3,0.1, -0.3,0.375,0.5},
{-0.3,0.3,0.3, -0.1,0.375,0.5},
{-0.5,0.4,0.3, -0.3,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "aset_2u.obj"
})

minetest.register_node("stones:s_3", {
	description = "Root 3 Split",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:s_3",
	collision_box = {type="fixed",fixed={
	{-0.5, -0.5, -0.5, 0.5, -0.36, 0.5},
	{-0.5, -0.36, -0.5, 0.25, -0.22, 0.5},
	{-0.25, -0.36, -0.25, 0.5, -0.22, 0.5},
	{-0.5, -0.22, -0.5, 0, -0.08, 0.5},
	{0, -0.22, -0.25, 0.25, -0.08, 0.5},
	{0.25, -0.22, 0, 0.5, -0.08, 0.5},
	{-0.5, -0.08, -0.5, -0.25, 0.08, 0.5},
	{-0.25, -0.08, -0.25, 0, 0.08, 0.5},
	{0, -0.08, 0, 0.25, 0.08, 0.5},
	{0.25, -0.08, 0.25, 0.5, 0.08, 0.5},
	{-0.5, 0.08, -0.25, -0.25, 0.22, 0.5},
	{-0.25, 0.08, 0, 0, 0.22, 0.5},
	{0, 0.08, 0.25, 0.25, 0.22, 0.5},
	{-0.5, 0.22, 0, -0.25, 0.36, 0.5},
	{-0.25, 0.22, 0.25, 0, 0.36, 0.5},
	{-0.5, 0.36, 0.25, -0.25, 0.5, 0.5}}},
	selection_box = {type="fixed",fixed={
	{-0.5, -0.5, -0.5, 0.5, -0.36, 0.5},
	{-0.5, -0.36, -0.5, 0.25, -0.22, 0.5},
	{-0.25, -0.36, -0.25, 0.5, -0.22, 0.5},
	{-0.5, -0.22, -0.5, 0, -0.08, 0.5},
	{0, -0.22, -0.25, 0.25, -0.08, 0.5},
	{0.25, -0.22, 0, 0.5, -0.08, 0.5},
	{-0.5, -0.08, -0.5, -0.25, 0.08, 0.5},
	{-0.25, -0.08, -0.25, 0, 0.08, 0.5},
	{0, -0.08, 0, 0.25, 0.08, 0.5},
	{0.25, -0.08, 0.25, 0.5, 0.08, 0.5},
	{-0.5, 0.08, -0.25, -0.25, 0.22, 0.5},
	{-0.25, 0.08, 0, 0, 0.22, 0.5},
	{0, 0.08, 0.25, 0.25, 0.22, 0.5},
	{-0.5, 0.22, 0, -0.25, 0.36, 0.5},
	{-0.25, 0.22, 0.25, 0, 0.36, 0.5},
	{-0.5, 0.36, 0.25, -0.25, 0.5, 0.5}}},
	drawtype = "mesh",
	mesh = "s_3.obj"
})

minetest.register_node("stones:vr", {
	description = "Vertex Removed",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vr",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.5, 0.4,-0.3,0.5},
{0.4,-0.4,-0.4, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.5, 0.3,-0.2,0.5},
{0.3,-0.3,-0.4, 0.4,-0.2,0.5},
{0.4,-0.3,-0.3, 0.5,-0.2,0.5},
{-0.5,-0.2,-0.5, 0.2,-0.1,0.5},
{0.2,-0.2,-0.4, 0.3,-0.1,0.5},
{0.3,-0.2,-0.3, 0.4,-0.1,0.5},
{0.4,-0.2,-0.2, 0.5,-0.1,0.5},
{-0.5,-0.1,-0.5, 0.1,0,0.5},
{0.1,-0.1,-0.4, 0.2,0,0.5},
{0.2,-0.1,-0.3, 0.3,0,0.5},
{0.3,-0.1,-0.2, 0.4,0,0.5},
{0.4,-0.1,-0.1, 0.5,0,0.5},
{-0.5,0,-0.5, 0,0.1,0.5},
{0,0,-0.4, 0.1,0.1,0.5},
{0.1,0,-0.3, 0.2,0.1,0.5},
{0.2,0,-0.2, 0.3,0.1,0.5},
{0.3,0,-0.1, 0.4,0.1,0.5},
{0.4,0,0, 0.5,0.1,0.5},
{-0.5,0.1,-0.5, -0.1,0.2,0.5},
{-0.1,0.1,-0.4, 0,0.2,0.5},
{0,0.1,-0.3, 0.1,0.2,0.5},
{0.1,0.1,-0.2, 0.2,0.2,0.5},
{0.2,0.1,-0.1, 0.3,0.2,0.5},
{0.3,0.1,0, 0.4,0.2,0.5},
{0.4,0.1,0.1, 0.5,0.2,0.5},
{-0.5,0.2,-0.5, -0.2,0.3,0.5},
{-0.2,0.2,-0.4, -0.1,0.3,0.5},
{-0.1,0.2,-0.3, 0,0.3,0.5},
{0,0.2,-0.2, 0.1,0.3,0.5},
{0.1,0.2,-0.1, 0.2,0.3,0.5},
{0.2,0.2,0, 0.3,0.3,0.5},
{0.3,0.2,0.1, 0.4,0.3,0.5},
{0.4,0.2,0.2, 0.5,0.3,0.5},
{-0.5,0.3,-0.5, -0.3,0.4,0.5},
{-0.3,0.3,-0.4, -0.2,0.4,0.5},
{-0.2,0.3,-0.3, -0.1,0.4,0.5},
{-0.1,0.3,-0.2, 0,0.4,0.5},
{0,0.3,-0.1, 0.1,0.4,0.5},
{0.1,0.3,0, 0.2,0.4,0.5},
{0.2,0.3,0.1, 0.3,0.4,0.5},
{0.3,0.3,0.2, 0.4,0.4,0.5},
{0.4,0.3,0.3, 0.5,0.4,0.5},
{-0.5,0.4,-0.5, -0.4,0.5,0.5},
{-0.4,0.4,-0.4, -0.3,0.5,0.5},
{-0.3,0.4,-0.3, -0.2,0.5,0.5},
{-0.2,0.4,-0.2, -0.1,0.5,0.5},
{-0.1,0.4,-0.1, 0,0.5,0.5},
{0,0.4,0, 0.1,0.5,0.5},
{0.1,0.4,0.1, 0.2,0.5,0.5},
{0.2,0.4,0.2, 0.3,0.5,0.5},
{0.3,0.4,0.3, 0.4,0.5,0.5},
{0.4,0.4,0.4, 0.5,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.5, 0.4,-0.3,0.5},
{0.4,-0.4,-0.4, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.5, 0.3,-0.2,0.5},
{0.3,-0.3,-0.4, 0.4,-0.2,0.5},
{0.4,-0.3,-0.3, 0.5,-0.2,0.5},
{-0.5,-0.2,-0.5, 0.2,-0.1,0.5},
{0.2,-0.2,-0.4, 0.3,-0.1,0.5},
{0.3,-0.2,-0.3, 0.4,-0.1,0.5},
{0.4,-0.2,-0.2, 0.5,-0.1,0.5},
{-0.5,-0.1,-0.5, 0.1,0,0.5},
{0.1,-0.1,-0.4, 0.2,0,0.5},
{0.2,-0.1,-0.3, 0.3,0,0.5},
{0.3,-0.1,-0.2, 0.4,0,0.5},
{0.4,-0.1,-0.1, 0.5,0,0.5},
{-0.5,0,-0.5, 0,0.1,0.5},
{0,0,-0.4, 0.1,0.1,0.5},
{0.1,0,-0.3, 0.2,0.1,0.5},
{0.2,0,-0.2, 0.3,0.1,0.5},
{0.3,0,-0.1, 0.4,0.1,0.5},
{0.4,0,0, 0.5,0.1,0.5},
{-0.5,0.1,-0.5, -0.1,0.2,0.5},
{-0.1,0.1,-0.4, 0,0.2,0.5},
{0,0.1,-0.3, 0.1,0.2,0.5},
{0.1,0.1,-0.2, 0.2,0.2,0.5},
{0.2,0.1,-0.1, 0.3,0.2,0.5},
{0.3,0.1,0, 0.4,0.2,0.5},
{0.4,0.1,0.1, 0.5,0.2,0.5},
{-0.5,0.2,-0.5, -0.2,0.3,0.5},
{-0.2,0.2,-0.4, -0.1,0.3,0.5},
{-0.1,0.2,-0.3, 0,0.3,0.5},
{0,0.2,-0.2, 0.1,0.3,0.5},
{0.1,0.2,-0.1, 0.2,0.3,0.5},
{0.2,0.2,0, 0.3,0.3,0.5},
{0.3,0.2,0.1, 0.4,0.3,0.5},
{0.4,0.2,0.2, 0.5,0.3,0.5},
{-0.5,0.3,-0.5, -0.3,0.4,0.5},
{-0.3,0.3,-0.4, -0.2,0.4,0.5},
{-0.2,0.3,-0.3, -0.1,0.4,0.5},
{-0.1,0.3,-0.2, 0,0.4,0.5},
{0,0.3,-0.1, 0.1,0.4,0.5},
{0.1,0.3,0, 0.2,0.4,0.5},
{0.2,0.3,0.1, 0.3,0.4,0.5},
{0.3,0.3,0.2, 0.4,0.4,0.5},
{0.4,0.3,0.3, 0.5,0.4,0.5},
{-0.5,0.4,-0.5, -0.4,0.5,0.5},
{-0.4,0.4,-0.4, -0.3,0.5,0.5},
{-0.3,0.4,-0.3, -0.2,0.5,0.5},
{-0.2,0.4,-0.2, -0.1,0.5,0.5},
{-0.1,0.4,-0.1, 0,0.5,0.5},
{0,0.4,0, 0.1,0.5,0.5},
{0.1,0.4,0.1, 0.2,0.5,0.5},
{0.2,0.4,0.2, 0.3,0.5,0.5},
{0.3,0.4,0.3, 0.4,0.5,0.5},
{0.4,0.4,0.4, 0.5,0.5,0.5}}},
drawtype = "mesh",
	mesh = "vr.obj"
})

minetest.register_node("stones:vr_2", {
	description = "Vertex Removed LowHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vr_2",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.5,-0.45,-0.5, 0.4,-0.4,0.5},
{0.4,-0.45,-0.4, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.5, 0.3,-0.35,0.5},
{0.3,-0.4,-0.4, 0.4,-0.35,0.5},
{0.4,-0.4,-0.3, 0.5,-0.35,0.5},
{-0.5,-0.35,-0.5, 0.2,-0.3,0.5},
{0.2,-0.35,-0.4, 0.3,-0.3,0.5},
{0.3,-0.35,-0.3, 0.4,-0.3,0.5},
{0.4,-0.35,-0.2, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.5, 0.1,-0.25,0.5},
{0.1,-0.3,-0.4, 0.2,-0.25,0.5},
{0.2,-0.3,-0.3, 0.3,-0.25,0.5},
{0.3,-0.3,-0.2, 0.4,-0.25,0.5},
{0.4,-0.3,-0.1, 0.5,-0.25,0.5},
{-0.5,-0.25,-0.5, 0,-0.2,0.5},
{0,-0.25,-0.4, 0.1,-0.2,0.5},
{0.1,-0.25,-0.3, 0.2,-0.2,0.5},
{0.2,-0.25,-0.2, 0.3,-0.2,0.5},
{0.3,-0.25,-0.1, 0.4,-0.2,0.5},
{0.4,-0.25,0, 0.5,-0.2,0.5},
{-0.5,-0.2,-0.5, -0.1,-0.15,0.5},
{-0.1,-0.2,-0.4, 0,-0.15,0.5},
{0,-0.2,-0.3, 0.1,-0.15,0.5},
{0.1,-0.2,-0.2, 0.2,-0.15,0.5},
{0.2,-0.2,-0.1, 0.3,-0.15,0.5},
{0.3,-0.2,0, 0.4,-0.15,0.5},
{0.4,-0.2,0.1, 0.5,-0.15,0.5},
{-0.5,-0.15,-0.5, -0.2,-0.1,0.5},
{-0.2,-0.15,-0.4, -0.1,-0.1,0.5},
{-0.1,-0.15,-0.3, 0,-0.1,0.5},
{0,-0.15,-0.2, 0.1,-0.1,0.5},
{0.1,-0.15,-0.1, 0.2,-0.1,0.5},
{0.2,-0.15,0, 0.3,-0.1,0.5},
{0.3,-0.15,0.1, 0.4,-0.1,0.5},
{0.4,-0.15,0.2, 0.5,-0.1,0.5},
{-0.5,-0.1,-0.5, -0.3,-0.05,0.5},
{-0.3,-0.1,-0.4, -0.2,-0.05,0.5},
{-0.2,-0.1,-0.3, -0.1,-0.05,0.5},
{-0.1,-0.1,-0.2, 0,-0.05,0.5},
{0,-0.1,-0.1, 0.1,-0.05,0.5},
{0.1,-0.1,0, 0.2,-0.05,0.5},
{0.2,-0.1,0.1, 0.3,-0.05,0.5},
{0.3,-0.1,0.2, 0.4,-0.05,0.5},
{0.4,-0.1,0.3, 0.5,-0.05,0.5},
{-0.5,-0.05,-0.5, -0.4,0,0.5},
{-0.4,-0.05,-0.4, -0.3,0,0.5},
{-0.3,-0.05,-0.3, -0.2,0,0.5},
{-0.2,-0.05,-0.2, -0.1,0,0.5},
{-0.1,-0.05,-0.1, 0,0,0.5},
{0,-0.05,0, 0.1,0,0.5},
{0.1,-0.05,0.1, 0.2,0,0.5},
{0.2,-0.05,0.2, 0.3,0,0.5},
{0.3,-0.05,0.3, 0.4,0,0.5},
{0.4,-0.05,0.4, 0.5,0,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,-0.45,0.5},
{-0.5,-0.45,-0.5, 0.4,-0.4,0.5},
{0.4,-0.45,-0.4, 0.5,-0.4,0.5},
{-0.5,-0.4,-0.5, 0.3,-0.35,0.5},
{0.3,-0.4,-0.4, 0.4,-0.35,0.5},
{0.4,-0.4,-0.3, 0.5,-0.35,0.5},
{-0.5,-0.35,-0.5, 0.2,-0.3,0.5},
{0.2,-0.35,-0.4, 0.3,-0.3,0.5},
{0.3,-0.35,-0.3, 0.4,-0.3,0.5},
{0.4,-0.35,-0.2, 0.5,-0.3,0.5},
{-0.5,-0.3,-0.5, 0.1,-0.25,0.5},
{0.1,-0.3,-0.4, 0.2,-0.25,0.5},
{0.2,-0.3,-0.3, 0.3,-0.25,0.5},
{0.3,-0.3,-0.2, 0.4,-0.25,0.5},
{0.4,-0.3,-0.1, 0.5,-0.25,0.5},
{-0.5,-0.25,-0.5, 0,-0.2,0.5},
{0,-0.25,-0.4, 0.1,-0.2,0.5},
{0.1,-0.25,-0.3, 0.2,-0.2,0.5},
{0.2,-0.25,-0.2, 0.3,-0.2,0.5},
{0.3,-0.25,-0.1, 0.4,-0.2,0.5},
{0.4,-0.25,0, 0.5,-0.2,0.5},
{-0.5,-0.2,-0.5, -0.1,-0.15,0.5},
{-0.1,-0.2,-0.4, 0,-0.15,0.5},
{0,-0.2,-0.3, 0.1,-0.15,0.5},
{0.1,-0.2,-0.2, 0.2,-0.15,0.5},
{0.2,-0.2,-0.1, 0.3,-0.15,0.5},
{0.3,-0.2,0, 0.4,-0.15,0.5},
{0.4,-0.2,0.1, 0.5,-0.15,0.5},
{-0.5,-0.15,-0.5, -0.2,-0.1,0.5},
{-0.2,-0.15,-0.4, -0.1,-0.1,0.5},
{-0.1,-0.15,-0.3, 0,-0.1,0.5},
{0,-0.15,-0.2, 0.1,-0.1,0.5},
{0.1,-0.15,-0.1, 0.2,-0.1,0.5},
{0.2,-0.15,0, 0.3,-0.1,0.5},
{0.3,-0.15,0.1, 0.4,-0.1,0.5},
{0.4,-0.15,0.2, 0.5,-0.1,0.5},
{-0.5,-0.1,-0.5, -0.3,-0.05,0.5},
{-0.3,-0.1,-0.4, -0.2,-0.05,0.5},
{-0.2,-0.1,-0.3, -0.1,-0.05,0.5},
{-0.1,-0.1,-0.2, 0,-0.05,0.5},
{0,-0.1,-0.1, 0.1,-0.05,0.5},
{0.1,-0.1,0, 0.2,-0.05,0.5},
{0.2,-0.1,0.1, 0.3,-0.05,0.5},
{0.3,-0.1,0.2, 0.4,-0.05,0.5},
{0.4,-0.1,0.3, 0.5,-0.05,0.5},
{-0.5,-0.05,-0.5, -0.4,0,0.5},
{-0.4,-0.05,-0.4, -0.3,0,0.5},
{-0.3,-0.05,-0.3, -0.2,0,0.5},
{-0.2,-0.05,-0.2, -0.1,0,0.5},
{-0.1,-0.05,-0.1, 0,0,0.5},
{0,-0.05,0, 0.1,0,0.5},
{0.1,-0.05,0.1, 0.2,0,0.5},
{0.2,-0.05,0.2, 0.3,0,0.5},
{0.3,-0.05,0.3, 0.4,0,0.5},
{0.4,-0.05,0.4, 0.5,0,0.5}}},
	drawtype = "mesh",
	mesh = "vr_2.obj"
})

minetest.register_node("stones:vr_2u", {
	description = "Vertex Removed HighHalf",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:vr_2u",
	collision_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0.5},
{-0.5,0,-0.5, 0.4,0.06,0.5},
{0.4,0,-0.4, 0.5,0.06,0.5},
{-0.5,0.06,-0.5, 0.3,0.12,0.5},
{0.3,0.06,-0.4, 0.4,0.12,0.5},
{0.4,0.06,-0.3, 0.5,0.12,0.5},
{-0.5,0.12,-0.5, 0.2,0.18,0.5},
{0.2,0.12,-0.4, 0.3,0.18,0.5},
{0.3,0.12,-0.3, 0.4,0.18,0.5},
{0.4,0.12,-0.2, 0.5,0.18,0.5},
{-0.5,0.18,-0.5, 0.1,0.24,0.5},
{0.1,0.18,-0.4, 0.2,0.24,0.5},
{0.2,0.18,-0.3, 0.3,0.24,0.5},
{0.3,0.18,-0.2, 0.4,0.24,0.5},
{0.4,0.18,-0.1, 0.5,0.24,0.5},
{-0.5,0.24,-0.5, 0,0.3,0.5},
{0,0.24,-0.4, 0.1,0.3,0.5},
{0.1,0.24,-0.3, 0.2,0.3,0.5},
{0.2,0.24,-0.2, 0.3,0.3,0.5},
{0.3,0.24,-0.1, 0.4,0.3,0.5},
{0.4,0.24,0, 0.5,0.3,0.5},
{-0.5,0.3,-0.5, -0.1,0.35,0.5},
{-0.1,0.3,-0.4, 0,0.35,0.5},
{0,0.3,-0.3, 0.1,0.35,0.5},
{0.1,0.3,-0.2, 0.2,0.35,0.5},
{0.2,0.3,-0.1, 0.3,0.35,0.5},
{0.3,0.3,0, 0.4,0.35,0.5},
{0.4,0.3,0.1, 0.5,0.35,0.5},
{-0.5,0.35,-0.5, -0.2,0.4,0.5},
{-0.2,0.35,-0.4, -0.1,0.4,0.5},
{-0.1,0.35,-0.3, 0,0.4,0.5},
{0,0.35,-0.2, 0.1,0.4,0.5},
{0.1,0.35,-0.1, 0.2,0.4,0.5},
{0.2,0.35,0, 0.3,0.4,0.5},
{0.3,0.35,0.1, 0.4,0.4,0.5},
{0.4,0.35,0.2, 0.5,0.4,0.5},
{-0.5,0.4,-0.5, -0.3,0.45,0.5},
{-0.3,0.4,-0.4, -0.2,0.45,0.5},
{-0.2,0.4,-0.3, -0.1,0.45,0.5},
{-0.1,0.4,-0.2, 0,0.45,0.5},
{0,0.4,-0.1, 0.1,0.45,0.5},
{0.1,0.4,0, 0.2,0.45,0.5},
{0.2,0.4,0.1, 0.3,0.45,0.5},
{0.3,0.4,0.2, 0.4,0.45,0.5},
{0.4,0.4,0.3, 0.5, 0.45,0.5},
{-0.5,0.45,-0.5, -0.4,0.5,0.5},
{-0.4,0.45,-0.4, -0.3,0.5,0.5},
{-0.3,0.45,-0.3, -0.2,0.5,0.5},
{-0.2,0.45,-0.2, -0.1,0.5,0.5},
{-0.1,0.45,-0.1, 0,0.5,0.5},
{0,0.45,0, 0.1,0.5,0.5},
{0.1,0.45,0.1, 0.2,0.5,0.5},
{0.2,0.45,0.2, 0.3,0.5,0.5},
{0.3,0.45,0.3, 0.4,0.5,0.5},
{0.4,0.45,0.4, 0.5,0.5,0.5}}},
	selection_box = {type="fixed",fixed={
{-0.5,-0.5,-0.5, 0.5,0,0.5},
{-0.5,0,-0.5, 0.4,0.06,0.5},
{0.4,0,-0.4, 0.5,0.06,0.5},
{-0.5,0.06,-0.5, 0.3,0.12,0.5},
{0.3,0.06,-0.4, 0.4,0.12,0.5},
{0.4,0.06,-0.3, 0.5,0.12,0.5},
{-0.5,0.12,-0.5, 0.2,0.18,0.5},
{0.2,0.12,-0.4, 0.3,0.18,0.5},
{0.3,0.12,-0.3, 0.4,0.18,0.5},
{0.4,0.12,-0.2, 0.5,0.18,0.5},
{-0.5,0.18,-0.5, 0.1,0.24,0.5},
{0.1,0.18,-0.4, 0.2,0.24,0.5},
{0.2,0.18,-0.3, 0.3,0.24,0.5},
{0.3,0.18,-0.2, 0.4,0.24,0.5},
{0.4,0.18,-0.1, 0.5,0.24,0.5},
{-0.5,0.24,-0.5, 0,0.3,0.5},
{0,0.24,-0.4, 0.1,0.3,0.5},
{0.1,0.24,-0.3, 0.2,0.3,0.5},
{0.2,0.24,-0.2, 0.3,0.3,0.5},
{0.3,0.24,-0.1, 0.4,0.3,0.5},
{0.4,0.24,0, 0.5,0.3,0.5},
{-0.5,0.3,-0.5, -0.1,0.35,0.5},
{-0.1,0.3,-0.4, 0,0.35,0.5},
{0,0.3,-0.3, 0.1,0.35,0.5},
{0.1,0.3,-0.2, 0.2,0.35,0.5},
{0.2,0.3,-0.1, 0.3,0.35,0.5},
{0.3,0.3,0, 0.4,0.35,0.5},
{0.4,0.3,0.1, 0.5,0.35,0.5},
{-0.5,0.35,-0.5, -0.2,0.4,0.5},
{-0.2,0.35,-0.4, -0.1,0.4,0.5},
{-0.1,0.35,-0.3, 0,0.4,0.5},
{0,0.35,-0.2, 0.1,0.4,0.5},
{0.1,0.35,-0.1, 0.2,0.4,0.5},
{0.2,0.35,0, 0.3,0.4,0.5},
{0.3,0.35,0.1, 0.4,0.4,0.5},
{0.4,0.35,0.2, 0.5,0.4,0.5},
{-0.5,0.4,-0.5, -0.3,0.45,0.5},
{-0.3,0.4,-0.4, -0.2,0.45,0.5},
{-0.2,0.4,-0.3, -0.1,0.45,0.5},
{-0.1,0.4,-0.2, 0,0.45,0.5},
{0,0.4,-0.1, 0.1,0.45,0.5},
{0.1,0.4,0, 0.2,0.45,0.5},
{0.2,0.4,0.1, 0.3,0.45,0.5},
{0.3,0.4,0.2, 0.4,0.45,0.5},
{0.4,0.4,0.3, 0.5, 0.45,0.5},
{-0.5,0.45,-0.5, -0.4,0.5,0.5},
{-0.4,0.45,-0.4, -0.3,0.5,0.5},
{-0.3,0.45,-0.3, -0.2,0.5,0.5},
{-0.2,0.45,-0.2, -0.1,0.5,0.5},
{-0.1,0.45,-0.1, 0,0.5,0.5},
{0,0.45,0, 0.1,0.5,0.5},
{0.1,0.45,0.1, 0.2,0.5,0.5},
{0.2,0.45,0.2, 0.3,0.5,0.5},
{0.3,0.45,0.3, 0.4,0.5,0.5},
{0.4,0.45,0.4, 0.5,0.5,0.5}}},
	drawtype = "mesh",
	mesh = "vr_2u.obj"
})

minetest.register_node("stones:micro", {
	description = "Microstone",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:micro",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, 0, 0, 0, 0.5}}}
})

minetest.register_node("stones:panel", {
	description = "Panel",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:panel",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, 0, 0.5, 0, 0.5}}}
})

minetest.register_node("stones:flat_1", {
	description = "Flat",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:flat_1",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}}}
})

minetest.register_node("stones:flat_2", {
	description = "Flat L",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:flat_2",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.5, 0.5, 0.5, -0.375}}}
})

minetest.register_node("stones:flat_3", {
	description = "Flat K",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:flat_2",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, 0.375, 0.5, 0.5, 0.5},
{0.375, -0.375, -0.5, 0.5, 0.5, 0.375}}}
})

minetest.register_node("stones:flat_3a", {
	description = "Flat U",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:flat_3a",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5},
{-0.5, -0.375, -0.5, 0.5, 0.5, -0.375},
{-0.5, -0.375, 0.375, 0.5, 0.5, 0.5}}}
})

minetest.register_node("stones:flat_4", {
	description = "Flat O",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:flat_4",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.375, 0.5, -0.375, 0.375},
{-0.5, -0.5, -0.5, 0.5, 0.5, -0.375},
{-0.5, -0.5, 0.375, 0.5, 0.5, 0.5},
{-0.5, 0.375, -0.375, 0.5, 0.5, 0.375}}}
})

minetest.register_node("stones:stair_3", {
	description = "3 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_3",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.1666, 0.5},
{-0.5, -0.1666, -0.1666, 0.5, 0.1666, 0.5},
{-0.5, 0.1666, 0.1666, 0.5, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_2", {
	description = "2 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_2of3", {
	description = "2/3 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2of3",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.1666, 0.5, -0.1666, 0.5},
{-0.5, -0.1666, 0.1666, 0.5, 0.1666, 0.5}}}
})

minetest.register_node("stones:stair_3_half_l", {
	description = "Half 3 Step Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_3_half_l",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0, -0.1666, 0.5},
{-0.5, -0.1666, -0.1666, 0, 0.1666, 0.5},
{-0.5, 0.1666, 0.1666, 0, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_3_half_r", {
	description = "Half 3 Step Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_3_half_r",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{0, -0.5, -0.5, 0.5, -0.1666, 0.5},
{0, -0.1666, -0.1666, 0.5, 0.1666, 0.5},
{0, 0.1666, 0.1666, 0.5, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_half_l", {
	description = "Half 2 Step Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2_half_l",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0, 0, 0.5},
{-0.5, 0, 0, 0, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_half_r", {
	description = "Half 2 Step Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2_half_r",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{0, -0.5, -0.5, 0.5, 0, 0.5},
{0, 0, 0, 0.5, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_2of3_half_l", {
	description = "Half 2/3 Step Left",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2of3_half_l",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.1666, 0, -0.1666, 0.5},
{-0.5, -0.1666, 0.1666, 0, 0.1666, 0.5}}}
})

minetest.register_node("stones:stair_2of3_half_r", {
	description = "Half 2/3 Step Right",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2of3_half_r",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{0, -0.5, -0.1666, 0.5, -0.1666, 0.5},
{0, -0.1666, 0.1666, 0.5, 0.1666, 0.5}}}
})

minetest.register_node("stones:stair_7", {
	description = "Inner 2 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_7",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, 0, 0.5},
{-0.5, 0, 0, 0.5, 0.5, 0.5},
{-0.5, 0, -0.5, 0, 0.5, 0}}}
})

minetest.register_node("stones:stair_5", {
	description = "Outer 2 step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_5",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, 0, 0.5},
{-0.5, 0, 0, 0, 0.5, 0.5}}}
})

minetest.register_node("stones:stair_941", {
	description = "Outer 3 step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_941",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.1666, 0.5},
{-0.1666, -0.1666, -0.5, 0.5, 0.1666, 0.1666},
{0.1666, 0.1666, -0.5, 0.5, 0.5, -0.1666}}}
})

minetest.register_node("stones:stair_5of14", {
	description = "Outer 2/3 step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_5of14",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.1666, -0.5, -0.1666, 0.5, -0.1666, 0.5},
{0.1666, -0.1666, 0.1666, 0.5, 0.1666, 0.5}}}
})

minetest.register_node("stones:stair_3_inner", {
	description = "Inner 3 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_3_inner",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.5, 0.5, -0.1666, 0.5},
{0.1666, -0.1666, -0.5, 0.5, 0.5, 0.5},
{-0.5, -0.1666, 0.1666, 0.1666, 0.5, 0.5},
{-0.1666, -0.1666, -0.5, 0.1666, 0.1666, 0.1666},
{-0.5, -0.1666, -0.1666, -0.1666, 0.1666, 0.1666}}}
})

minetest.register_node("stones:stair_2of3_inner", {
	description = "Inner 2/3 Step",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png"},
	groups = {cracky=3, oddly_breakable_by_hand=0},
	drop = "stones:stair_2of3_inner",
	drawtype = "nodebox",
	node_box = {type="fixed",fixed={
{-0.5, -0.5, -0.1666, 0.5, -0.1666, 0.5},
{-0.1666, -0.5, -0.5, 0.5, -0.1666, 0.5},
{-0.5, -0.1666, 0.1666, 0.5, 0.1666, 0.5},
{0.1666, -0.1666, -0.5, 0.5, 0.1666, 0.1666}}}
})



