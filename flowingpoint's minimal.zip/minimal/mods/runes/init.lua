
--[[to do: register runes:rune_bu as the non-glowing rune, and default:rune_bu_glowing as the node timer that turns to regular stone.]]

screwdriver = screwdriver or {}
rune_bu = {}
rune_ke = {}
rune_hui = {}

rune_bu.min_duration = tonumber(minetest.settings:get("rune_bu_min_duration")) or 10
rune_bu.max_duration = tonumber(minetest.settings:get("rune_bu_max_duration")) or 30
rune_ke.min_duration = tonumber(minetest.settings:get("rune_ke_min_duration")) or 20
rune_ke.max_duration = tonumber(minetest.settings:get("rune_ke_max_duration")) or 25

minetest.register_lbm({
	name = ":rune_bu:convert_rune_to_node_timer",
	nodenames = {"default:rune_bu"},
	action = function(pos)

		if not minetest.get_node_timer(pos):is_started() then

			minetest.get_node_timer(pos):start(
					math.random(rune_bu.min_duration, rune_bu.max_duration))
		end
	end
})

minetest.register_lbm({
	name = ":rune_ke:convert_rune_to_node_timer",
	nodenames = {"default:rune_ke"},
	action = function(pos)

		if not minetest.get_node_timer(pos):is_started() then

			minetest.get_node_timer(pos):start(
					math.random(rune_ke.min_duration, rune_ke.max_duration))
		end
	end
})

-- creative check
local creative_mode_cache = minetest.settings:get_bool("creative_mode")

function is_creative(name)
	return creative_mode_cache or minetest.check_player_privs(name, {creative = true})
end

minetest.register_node("runes:lit_bu", {
	description = "Bu = Not",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png^opaq.png", "rock.png^opaq.png", "rock.png^opaq.png", "rock.png^opaq.png", "rock.png^opaq.png", {name = "rock_1x24.png^opaq_1x24.png^rune_bu_ani.png", animation = {type = "vertical_frames", length = 5.0}}},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "stones:rubble",
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}},
})

minetest.register_node("runes:bu", {
	description = "Not",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {
		"rock.png^[transformR270",
		"rock.png^[transformR90",
		"rock.png^[transformFX",
		"rock.png", "rock.png",
--[[{name = "rune_bu_glowing.png", animation = {type = "vertical_frames", length = 60.0}}]]
		"rock.png^runelay_bu.png"
		},
	light_source = 0,
	groups = {cracky=3},
	drop = 'runes:bu',
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("runes:lit_ke", {
	description = "May",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png^opaq.png", "rock.png^opaq.png", {name = "rock_1x24.png^opaq_1x24.png^rune_ke_ani.png", animation = {type = "vertical_frames", length = 4.0}}, "rock.png^opaq.png", "rock.png^opaq.png", "rock.png^opaq.png"},
	light_source = 5,
	groups = {cracky=1},
	drop = "stones:rubble",
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("runes:ke", {
	description = "Ke = May",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"rock.png^[transformR270",
		"rock.png^[transformR90",
		"rock.png^runelay_ke.png",
		"rock.png^[transformFX",
		"rock.png", "rock.png"},
	light_source = 0,
	groups = {cracky=3},
	drop = 'runes:ke',
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("runes:lit_hui", {
	description = "Hui = Return",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
tiles = {{name="runestone_1x24.png", animation = {type = "vertical_frames", length=3.0}}, "runestone.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "runes:lit_hui",
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

minetest.register_node("runes:hui", {
	description = "Hui = Return",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"runestone.png", "rock.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 0,
	groups = {cracky=3},
	drop = 'runes:hui',
	node_box = {type = "fixed", fixed = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}}
})

function c(n)
	return n/32-1/2
end

minetest.register_node("runes:nbdx1", {
	description = "Niu Bi Da Xue Yi",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
tiles = {{name="nbdx1_1x11.png", animation = {type = "vertical_frames", length=3.0}}, "rubble.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "runes:nbdx1",
	node_box = {type = "fixed", fixed = {
	{c(0),c(0),c(0), c(1),c(32),c(10)},
	{c(1),c(0),c(0), c(2),c(32),c(13)},
	{c(2),c(0),c(0), c(3),c(32),c(15)},
	{c(3),c(0),c(0), c(4),c(32),c(17)},
	{c(4),c(0),c(0), c(5),c(32),c(18)},
	{c(5),c(0),c(0), c(6),c(32),c(19)},
	{c(6),c(0),c(0), c(7),c(32),c(20)},
	{c(7),c(0),c(0), c(8),c(32),c(22)},
	{c(8),c(0),c(0), c(9),c(32),c(23)},
	{c(9),c(0),c(0), c(10),c(32),c(24)},
	{c(10),c(0),c(0), c(12),c(32),c(25)},
	{c(12),c(0),c(0), c(13),c(32),c(26)},
	{c(13),c(0),c(0), c(14),c(32),c(27)},
	{c(14),c(0),c(0), c(15),c(32),c(28)},
	{c(15),c(0),c(0), c(17),c(32),c(29)},
	{c(17),c(0),c(0), c(19),c(32),c(30)},
	{c(19),c(0),c(0), c(22),c(32),c(31)},
	{c(22),c(0),c(0), c(32),c(32),c(32)}}},
})

minetest.register_node("runes:nbdx2", {
	description = "Niu Bi Da Xue Er",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
tiles = {{name="nbdx2_1x13.png", animation = {type = "vertical_frames", length=3.0}}, "rubble.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "runes:nbdx2",
	node_box = {type = "fixed", fixed = {
	{c(0), c(0), c(0), c(10), c(32), c(32)},
	{c(10),c(0),c(0), c(13),c(32),c(31)},
	{c(13),c(0),c(0), c(15),c(32),c(30)},
	{c(15),c(0),c(0), c(17),c(32),c(29)},
	{c(17),c(0),c(0), c(18),c(32),c(28)},
	{c(18),c(0),c(0), c(19),c(32),c(27)},
	{c(19),c(0),c(0), c(20),c(32),c(26)},
	{c(20),c(0),c(0), c(22),c(32),c(25)},
	{c(22),c(0),c(0), c(23),c(32),c(24)},
	{c(23),c(0),c(0), c(24),c(32),c(23)},
	{c(24),c(0),c(0), c(25),c(32),c(22)},
	{c(25),c(0),c(0), c(26),c(32),c(20)},
	{c(26),c(0),c(0), c(27),c(32),c(19)},
	{c(27),c(0),c(0), c(28),c(32),c(18)},
	{c(28),c(0),c(0), c(29),c(32),c(17)},
	{c(29),c(0),c(0), c(30),c(32),c(15)},	
	{c(30),c(0),c(0), c(31),c(32),c(13)},
	{c(31),c(0),c(0), c(32),c(32),c(10)}}},
})

minetest.register_node("runes:nbdx3", {
	description = "Niu Bi Da Xue San",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
tiles = {{name="nbdx3_1x17.png", animation = {type = "vertical_frames", length=3.0}}, "rubble.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "runes:nbdx3",
	node_box = {type = "fixed", fixed = {
	{c(0),c(0),c(0), c(10),c(32),c(32)},
	{c(10),c(0),c(1), c(13),c(32),c(32)},
	{c(13),c(0),c(2), c(15),c(32),c(32)},
	{c(15),c(0),c(3), c(17),c(32),c(32)},
	{c(17),c(0),c(4), c(18),c(32),c(32)},
	{c(18),c(0),c(5), c(19),c(32),c(32)},
	{c(19),c(0),c(6), c(20),c(32),c(32)},
	{c(20),c(0),c(7), c(22),c(32),c(32)},
	{c(22),c(0),c(8), c(23),c(32),c(32)},
	{c(23),c(0),c(9), c(24),c(32),c(32)},
	{c(24),c(0),c(10), c(25),c(32),c(32)},
	{c(25),c(0),c(12), c(26),c(32),c(32)},
	{c(26),c(0),c(13), c(27),c(32),c(32)},
	{c(27),c(0),c(14), c(28),c(32),c(32)},
	{c(28),c(0),c(15), c(29),c(32),c(32)},
	{c(29),c(0),c(17), c(30),c(32),c(32)},
	{c(30),c(0),c(19), c(31),c(32),c(32)},
	{c(31),c(0),c(22), c(32),c(32),c(32)}}},
})

minetest.register_node("runes:nbdx4", {
	description = "Niu Bi Da Xue Si",
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
tiles = {{name="nbdx4_1x19.png", animation = {type = "vertical_frames", length=3.0}}, "rubble.png", "rock.png", "rock.png", "rock.png", "rock.png"},
	light_source = 5,
	groups = {cracky=1, oddly_breakable_by_hand=0},
	drop = "runes:nbdx4",
	node_box = {type = "fixed", fixed = {
	{c(0),c(0),c(22), c(1),c(32),c(32)},
	{c(1),c(0),c(19), c(2),c(32),c(32)},
	{c(2),c(0),c(17), c(3),c(32),c(32)},
	{c(3),c(0),c(15), c(4),c(32),c(32)},
	{c(4),c(0),c(14), c(5),c(32),c(32)},
	{c(5),c(0),c(13), c(6),c(32),c(32)},
	{c(6),c(0),c(12), c(7),c(32),c(32)},
	{c(7),c(0),c(10), c(8),c(32),c(32)},
	{c(8),c(0),c(9), c(9),c(32),c(32)},
	{c(9),c(0),c(8), c(10),c(32),c(32)},
	{c(10),c(0),c(7), c(12),c(32),c(32)},
	{c(12),c(0),c(6), c(13),c(32),c(32)},
	{c(13),c(0),c(5), c(14),c(32),c(32)},
	{c(14),c(0),c(4), c(15),c(32),c(32)},
	{c(15),c(0),c(3), c(17),c(32),c(32)},
	{c(17),c(0),c(2), c(19),c(32),c(32)},
	{c(19),c(0),c(1), c(22),c(32),c(32)},
	{c(22),c(0),c(0), c(32),c(32),c(32)}}},
})

