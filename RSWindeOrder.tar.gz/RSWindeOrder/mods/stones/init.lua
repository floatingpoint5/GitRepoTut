local path = minetest.get_modpath("stones")

dofile(path .. "/sto1.lua")
dofile(path .. "/sto2.lua")
dofile(path .. "/sto3.lua")
dofile(path .. "/sto4.lua")
dofile(path .. "/sto5.lua")
dofile(path .. "/sto6.lua")