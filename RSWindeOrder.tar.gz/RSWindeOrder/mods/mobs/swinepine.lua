local S = mobs.intllib
local current_animation = {}
local animations = {
	move = {
		basepos = {x = 0, y = 0},
		frames = 7,
		framelength = 0.3,
	},
	idle = {
		basepos = {x = 0, y = 0},
		frames = 1,
		framelength = 1,
	},
}

local switch_animation = function(player, animation)
	if current_animation[player:get_player_name()] == animation then
		return
	end
	local anim_def = animations[animation]
	local basepos = { x = 0, y = 0}
	if anim_def.basepos then
		basepos = anim_def.basepos
	end
	local frames = 1
	if anim_def.frames then
		frames = anim_def.frames
	end
	player:set_sprite(basepos, frames, anim_def.framelength, true)
	current_animation[player:get_player_name()] = animation
end

minetest.register_globalstep(function(dtime)
	-- Players' animation
	for _, player in pairs(minetest.get_connected_players()) do
		local controls = player:get_player_control()
		if controls.up or controls.down or controls.left or controls.right then
			switch_animation(player, "move")
			return
		end
		switch_animation(player, "idle")
	end
end)
--Guy from Vampire story who's girlfriend gets stolen by the vampire in the hotel.

mobs:register_mob("mobs:swinepine", {
   	description = "Swinepine",
	collide_with_objects = true,
	type = "npc",
	hp_min = 3,
	hp_max = 5,
	collisionbox = {-0.1, -1, -0.1, 0.1, 0.95, 0.1},
	visual = "upright_sprite",
	visual_size = {x=1,y=2},
	spritediv = {x = 4, y = 7},
	textures = {{"swinepine_f.png","swinepine_r.png"}},
	on_activate = function(self, dtime)
		self.object:set_sprite({x = 0, y = 0}, animations.move.frames, animations.move.framelength, true)
	end,
	walk_velocity = 0,
	run_velocity = 5,
	follow = {"mobs:swinepine"},
	jump = false,
	jump_height = 0.025,
	view_range = 20,
	light_damage = -1,
	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 8, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})

mobs:register_egg("mobs:swinepine", "Swinepine", "swinepine_f.png")

